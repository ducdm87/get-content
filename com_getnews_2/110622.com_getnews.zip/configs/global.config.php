vov					giam id
baomoi				giam id
vnmedia				duyet theo category. Lay danh sach bai viec trong moi bai viet cuoi cung
ktdt				duyet theo category. Lay danh sach bai viec trong moi bai viet cuoi cung
thethaovanhoa		duyet tung category. Next tung trang
nguoilaodong		duyet tung category. Next tung trang
vietnamnet			duyet tung category. Next tung trang
thanhnien			duyet tung category. Danh sach bai viet theo trang moi ngay
autonet				duyet theo category. Danh sach bai viet trong 1 file xml	http://autonet.com.vn/search/select/?q=siteid:258%20AND%20cateid:4632&start=0&rows=30&r=&wt=xml

<?php
$mysql_timout	=	100;