<?php
//giam id;
// link run: http://domain.com/index.php?option=com_getnewsvov&task=getnews&host=vovnews
// start auto_increment	:	100.101.021

/**
 * *	thoi gian cho moi lan chay lay bai
 */
$time_exp	=	15;
/**
 * - true: lấy lại bài viết
 * - false: b�? qua bài viết đã lấy
 */
$get_existing	= false;
/**
 * - true: lấy bài viết cũ. sử dụng cho lần chạy đầu tiên. lấy vét cạn
 * - false: chỉ lấy bài viết mới
 */
$get_multicat		= true;
/**
 * : 	đư�?ng dẫn đến thư mục ảnh
 */
$path_image		=	'images/plh190';
/**
 * địa chỉ tới nơi chứa ảnhvd
 */
$link_image		=	'/images/plh190'	;
$section_id		=	1;
$catid			=	1;
/**
 * 
 */
$SiteID 		=	'plh190';