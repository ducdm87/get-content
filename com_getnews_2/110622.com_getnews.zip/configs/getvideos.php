<?php
// giam id
// link run: http://domain.com/index.php?option=com_getnewsvov&task=getnews&host=en.vovnews
// start auto_increment	:	105.012.101
$id_started	=	'85000';
/**
 * *	thoi gian cho moi lan chay lay bai
 */
$time_exp	=	100;
/**
 *		so luong bai can lay cho moi lan
 */
$get_existing	= false;
/**
 * - true: lấy bài viết cũ. sử dụng cho lần chạy đầu tiên. lấy vét cạn
 * - false: chỉ lấy bài viết mới
 */
$get_old		= true;
/**
 * : 	đường dẫn đến thư mục ảnh
 */
$path_save		=	'videos/ttvh/';
