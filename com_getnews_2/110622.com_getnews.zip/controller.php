<?php

function mosControlerGetMedia()
{
	get_image();
	
}