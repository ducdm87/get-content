
        <?php
        // no direct access
        defined('_VALID_MOS') or die('Restricted access');
        $lastGet_Id = "-1";
        $checkedout = 0;       
        $cache_exp = '2011-06-22 11:04:06';
        