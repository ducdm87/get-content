
        <?php
        // no direct access
        defined('_VALID_MOS') or die('Restricted access');
        $lastGet_Id = "6478900";
        $checkedout = 0;       
        $cache_exp = '2011-06-20 12:17:04';
        