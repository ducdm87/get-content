<?php
//giam id;
// link run: http://domain.com/index.php?option=com_getnewsvov&task=getnews&host=vovnews
// start auto_increment	:	100.101.021

$id_started	=	'100001';
/**
 * *	thoi gian cho moi lan chay lay bai
 */
$time_exp	=	10;
/**
 *		so luong bai can lay cho moi lan
 */
$numbercontent	=	20;
/**
 * - true: lấy lại bài viết
 * - false: bỏ qua bài viết đã lấy
 */
$get_existing	= false;
/**
 * - true: lấy bài viết cũ. sử dụng cho lần chạy đầu tiên. lấy vét cạn
 * - false: chỉ lấy bài viết mới
 */
$get_old		= true;
/**
 * : 	đường dẫn đến thư mục ảnh
 */
$path_image		=	'images/vn10';
/**
 * địa chỉ tới nơi chứa ảnhvd
 */
$link_image		=	'/images/vn10'	;
$section_id		=	1;
$catid			=	1;
/**
 * 
 */
$SiteID 		=	'vn10';