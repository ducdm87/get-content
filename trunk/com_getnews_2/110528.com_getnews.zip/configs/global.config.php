<?php


$mysql_timout	=	100;