
        <?php
        // no direct access
        defined('_VALID_MOS') or die('Restricted access');
        $lastGet_Id = "0";
        $checkedout = 0;       
        $cache_exp = '2011-05-27 18:07:38';
        