<?php
/*
 * @filename 	: getnews.php
 * @version  	: 1.0
 * @package	 	: vietbao.vn/get news/
 * @subpackage	: component
 * @license		: GNU/GPL 3, see LICENSE.php
 * @author 		: DucDM, HaiNH
 * @authorEmail	: ducdm87@binhhoang.com, hainh@binhhoang.com
 * @copyright	: Copyright (C) 2011 Vi?t b�o�. All rights reserved. 
 */

defined('_VALID_MOS') or die('Restricted access');
define( 'DS', DIRECTORY_SEPARATOR );
if (!class_exists('loadHtml')) 
{
	require('libraries/helpers/parse.php');
}
if (!class_exists('QRequest')) {
	require_once('libraries/helpers/request.php')	;
	
}
if (!class_exists('phpWebHacks')) {
	require_once('libraries/helpers/phpWebHacks.php')	;
	
}
if (!class_exists('buildTree')) {
	require_once('libraries/helpers/buildTree.php')	;
	
}
if (!class_exists('href')) {
	require_once('libraries/helpers/href.php')	;
	
}
$task	=	$_REQUEST['task'];

global $database,$arrErr;
$arrErr	=	array();
require_once('libraries/db/banid.php');
require_once('libraries/db/param.php');
require_once('libraries/db/comment.php');
require_once('libraries/db/other.php');
require_once('libraries/db/db.php');
mosDB($database);
require_once('libraries/db/videos.php');
require_once('libraries/class/tidy_clean.php');

switch ($task)
{
	case 'getcategory':
		{
			require_once('controllers/category.php');
			require_once('models/category.php');	
			$host	=	$_REQUEST['host'];
			switch ($host) {
				case 'vovnews':
					mosControllerCategoryGetVOV();
					break;
				case 'en.vovnews':	
					mosControllerCategoryGetENVOV();
					break;	
				case 'baomoi':	
					mosControllerCategoryGetBAOMOI();
					break;	
				case 'en.vietnamnet':
					mosControllerCategoryGetENVIETNAMNET();
					break;	
				case 'ktdt':
					mosControllerCategoryGetKTDT();
					break;
				case 'thanhnien':
					mosControllerCategoryGetTHANHNIEN();
					break;
				case 'nguoilaodong':
					mosControllerCategoryGetNGUOILAODONG();
					break;
				case 'thethaovanhoa':
					mosControllerCategoryGetTheThaoVanHoa();
					break;
				case 'autonet':
					mosControllerCategoryGetAutoNet();
					break;
				case 'autopro':
					mosControllerCategoryGetAutoPro();
					break;
				case 'autotv':
					mosControllerCategoryGetAutoTV();
					break;
			}
			break;
		}
	case 'getnews':
		{
			$host	=	$_REQUEST['host'];
			switch ($host) {
				case 'vovnews':	
					require_once('controllers/newsvov.php');
					require_once('models/newsvov.php');	
					mosControllerNewsvovGetNews();
					break;
				case 'en.vovnews':
					require_once('controllers/newsEnvov.php');
					require_once('models/newsEnvov.php');
					mosControllerNewsEnvovGetNews();
					break;
				case 'en.baomoi':
					require_once('controllers/newsEnbaomoi.php');
					require_once('models/newsEnbaomoi.php');
					mosControllerNewsEnbaomoiGetNews();	
					break;	
				case 'baomoi':
					require_once('controllers/newsbaomoi.php');
					require_once('models/newsbaomoi.php');
					mosControllerNewsbaomoiGetNews();
					break;
				case 'ktdt':
					require_once('controllers/newsktdt.php');
					require_once('models/newsktdt.php');
					mosControllerNewsktdtGetNews();	
					break;
				case 'en.vietnamnet':
					require_once('controllers/newsEnvietnamnet.php');
					require_once('models/newsEnvietnamnet.php');
					mosControllerNewsEnvietnamnetGetNews();	
					break;
				case 'en.thanhnien':
					require_once('controllers/newsEnthanhnien.php');
					require_once('models/newsEnthanhnien.php');
					mosControllerNewsEnthanhNienGetNews();
					break;	
				case 'nguoilaodong':
					require_once('controllers/newsNguoiLaoDong.php');
					require_once('models/newsNguoiLaoDong.php');
					mosControllerNguoiLaoDongGetNews();	
					break;
				case 'thethaovanhoa':
					require_once('controllers/newsTheThaoVanHoa.php');
					require_once('models/newsTheThaoVanHoa.php');
					require_once('libraries/helpers/autocuttext.php');
					mosControllerTheThaoVanHoaGetNews();
					break;
				case 'getvideos':
					require_once('controllers/get_video.php');
					require_once('models/get_video.php');
					mosControllerTheThaoVanHoaGetVideo();
					break;
				case 'autonet':
					require_once('controllers/newsAutoNet.php');
					require_once('models/newsAutoNet.php');		
					require_once('libraries/helpers/autocuttext.php');
					mosControllerNewsautoNetGetNews();	
					break;
				case 'autopro':
					require_once('controllers/newsAutoPro.php');
					require_once('models/newsAutoPro.php');	
					require_once('libraries/helpers/autocuttext.php');
					mosControllerAutoProGetNews();	
					break;	
				case 'autohui':
					require_once('controllers/newsAutoHui.php');
					require_once('models/newsAutoHui.php');		
					require_once('libraries/helpers/autocuttext.php');
					mosControllerAutoHuiGetNews();	
					break;
				case 'autotv':
					require_once('controllers/newsAutoTV.php');
					require_once('models/newsAutoTV.php');		
					require_once('libraries/helpers/autocuttext.php');
					mosControllerAutoTVGetNews();
					break;	
			}
			break;
		}
	case 'getnewsvov':
			require_once('controllers/newsvov.php');
			require_once('models/newsvov.php');
			require_once('libraries/class/images.php');
			mosControllerNewsvovGetVOV();	
			break;
	case 'getnewsvov.en':
			require_once('controllers/newsEnvov.php');
			require_once('models/newsEnvov.php');
			require_once('libraries/class/images.php');
			mosControllerNewsEnvovGetVOV();
			break;
	case 'getnewsbaomoi.en':
			require_once('controllers/newsEnbaomoi.php');
			require_once('models/newsEnbaomoi.php');
			require_once('libraries/class/images.php');
			require_once('libraries/class/date.php');
			mosControllerNewsENbaomoiGetBM();
			break;
	case 'getnewsbaomoi':
			require_once('controllers/newsbaomoi.php');
			require_once('models/newsbaomoi.php');
			require_once('libraries/class/images.php');
			require_once('libraries/class/date.php');
			mosControllerNewsbaomoiGetBM();
			break;	
	case 'getnewsktdt':
			require_once('controllers/newsktdt.php');
			require_once('models/newsktdt.php');
			require_once('libraries/class/images.php');
			require_once('libraries/class/date.php');
			mosControllerNewsktdtGetKTDT();
			break;	
	case 'getnewsvnnet.en':
			require_once('controllers/newsEnvietnamnet.php');
			require_once('models/newsEnvietnamnet.php');
			require_once('libraries/class/images.php');
			require_once('libraries/class/date.php');
			mosControllerNewsVietnamnetGetVNN();
			break;
	case 'getnewsthanhnien.en':
			require_once('controllers/newsEnthanhnien.php');
			require_once('models/newsEnthanhnien.php');
			require_once('libraries/helpers/autocuttext.php');
			require_once('libraries/class/images.php');
			require_once('libraries/class/date.php');
			mosControllerNewsEnthanhNienGetVNN();
			break;
	case 'nguoilaodong.vn':
			require_once('controllers/newsNguoiLaoDong.php');
			require_once('models/newsNguoiLaoDong.php');
			require_once('libraries/class/images.php');
			require_once('libraries/class/date.php');
			mosControllerNguoiLaoDongGetNLD();		
			break;
	case 'thethaovanhoa.vn':
			require_once('controllers/newsTheThaoVanHoa.php');
			require_once('models/newsTheThaoVanHoa.php');	
			require_once('libraries/helpers/autocuttext.php');
			require_once('libraries/class/images.php');
			require_once('libraries/class/date.php');
			mosControllerTheThaoVanHoaGetTTVH();
			break;	
	case 'getvideos':
			require_once('controllers/get_video.php');
			require_once('models/get_video.php');
			mosControllerGetVideoContent();
			break;	
	case 'getnewsautonet':
			require_once('controllers/newsAutoNet.php');
			require_once('models/newsAutoNet.php');	
			require_once('libraries/helpers/autocuttext.php');
			require_once('libraries/class/images.php');
			require_once('libraries/class/date.php');
			mosControllerNewsautoNetGetAtn();		
			break;	
	case 'autopro.vn':
			require_once('controllers/newsAutoPro.php');
			require_once('models/newsAutoPro.php');	
			require_once('libraries/helpers/autocuttext.php');
			require_once('libraries/class/images.php');
			require_once('libraries/class/date.php');
			mosControllerAutoProGetATP();
			break;
	case 'autohui.vn':
			require_once('controllers/newsAutoHui.php');
			require_once('models/newsAutoHui.php');	
			require_once('libraries/helpers/autocuttext.php');
			require_once('libraries/class/images.php');
			require_once('libraries/class/date.php');
			mosControllerAutoHuiGetATH();
			break;
	case 'autotv':
			require_once('controllers/newsAutoTV.php');
			require_once('models/newsAutoTV.php');	
			require_once('libraries/helpers/autocuttext.php');
			require_once('libraries/class/images.php');
			require_once('libraries/class/date.php');
			mosControllerAutoTVGetATTV();
			break;
	default:
			break;
}