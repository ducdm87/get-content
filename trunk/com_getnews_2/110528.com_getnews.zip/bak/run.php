vov				100.101.021		10
en.vov			105.012.101		10
	ktdt			110.201.110		18
	en.thanhnien	115.121.101		25
en.vietnamnet	120.110.012		20

baomoi			200.121.140		12
en.baomoi		240.213.110		15

http://getnewsvov.com/index.php?option=com_getnews&task=getnews&host=vovnews
http://getnewsvov.com/index.php?option=getnews&task=getnews&host=en.vovnews
http://getnewsvov.com/index.php?option=getnews&task=getnews&host=baomoi
http://getnewsvov.com/index.php?option=getnews&task=getnews&host=en.baomoi
http://getnewsvov.com/index.php?option=getnews&task=getnews&host=ktdt
http://getnewsvov.com/index.php?option=getnews&task=getnews&host=autonet

http://getnewsvov.com/index.php?option=getnews&task=getnews&host=en.vietnamnet
http://getnewsvov.com/index.php?option=getnews&task=getnews&host=en.thanhnien
http://getnewsvov.com/index.php?option=getnews&task=getnews&host=nguoilaodong
http://getnewsvov.com/index.php?option=getnews&task=getnews&host=thethaovanhoa

===========================================================================================
http://localhost/110523_getnews/index.php?option=com_getnews&task=getnews&host=autonet



