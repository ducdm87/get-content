<?php

$data_category	=	array();

/////////////////////////////////////////////////////////////////////////////////////////
	//////////////  FOR VOV	/////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

/**
 * Get listcategory of vov
 *
 * @param unknown_type $url
 * @return unknown
 */
function mosModelCategoryGetVOV($url = null)
{
	if ($url == null) {
		$url	=	'http://english.vovnews.vn';
	}	
	$browser	=	new phpWebHacks();
	$response	=	$browser->get($url);
	
	$reg		=	'/<div[^>]*id="mainnav"[^>]*>\s*<ul>(.*?)<\/ul>\s*<\/div>\s*<div[^>]*id="secondary"[^>]*>/ism';
	
	if (!preg_match($reg,$response,$matches)) {
		return false;
	}	
	$tree	=	new buildTreeVOV();
	$arr_data	=	$tree->getTree($matches[1],$url);
	return $arr_data;
}
/**
 * Store category of vov
 *
 * @param unknown_type $data
 * @param unknown_type $section_id
 * @return unknown
 */
function mosModelCategorySaveVOV($data , $section_id = 1)
{	
	if (!is_array($data) || count($data)<1) {
		return false;
	}
	
	global $database;
	$db	=	$database;
	foreach ($data as $category)
	{
		// check article2010_category_vov
		$query	=	'SELECT COUNT(*) 
					FROM `#__article2010_category_vov` 
					WHERE `link` = '.$db->Quote($category->link);
		$db->setQuery($query);		
		$result	=	$db->loadResult();
		if ($result) {
			continue;
		}
		$jl_category	=	'';
		$parent			=	'';
		if ($category->parent != -1) {
			$query	=	'SELECT id,jl_category  
											FROM `#__article2010_category_vov` 
											WHERE `link`='. $db->Quote($data[$category->parent]->link);
			$db->setQuery($query);
			$db->loadObject($parent);			
			$jl_category	=	$parent->jl_category;
			$parent			=	$parent->id;
		}
		// store category
		$row_caregory				=	new	mosCategory($db);
		$row_caregory->parent_id	=	$parent;
		$row_caregory->title		=	$category->title;
		$row_caregory->name			=	$category->title;
		$row_caregory->section		=	$section_id;
				
		if (! $row_caregory->store ()) {
			echo "<script> alert('" . $row_caregory->getError () . "'); window.history.go(-1); </script>\n";
			exit ();
		}
		// store vov_category
		$row_vov_caregory				=	new mosVovCategory($db);
		$row_vov_caregory->jl_category	=	$row_caregory->id;
		$row_vov_caregory->title		=	$category->title;
		$row_vov_caregory->link			=	$category->link;
		$row_vov_caregory->parent		=	$parent;
		if (! $row_vov_caregory->store ()) {
			echo "<script> alert('" . $row_vov_caregory->getError () . "'); window.history.go(-1); </script>\n";
			exit ();
		}
	}
	return true;
}


////////////////////////////////////////////////////////////////////////////////////
	////////////////	FOR BAOMOI	/////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
/**
 * Get list category of baomoi
 *
 * @param unknown_type $url
 * @return unknown
 */
function mosModelCategoryGetBAOMOI($url = null, $link_js)
{
	if ($url == null) {
		$url	=	'http://www.baomoi.com/';
		$link_js	=	'http://static.baomoi.vn/JScripts/static_menu.js';
	}
	$browser	=	new phpWebHacks();
	$response	=	$browser->get($link_js);
	
	$js_command	=	explode(';',$response);
	$command	=	$js_command[1];
	$command	=	str_replace('\"','sperator_VB',$command);
	$command	=	str_replace('"','',$command);
	$command	=	str_replace('\\','',$command);
	$command	=	str_replace('sperator_VB','"',$command);
	$command	=	str_replace('menu +=','',$command);	
	
	$reg		=	'/<div[^>]*class="wrapNavi"[^>]*>(.*?)<\/div>/ism';
	
	if (!preg_match($reg,$command,$matches)) {
		return false;
	}	
	$tree	=	new buildTreeBAOMOI();
	$arr_data	=	$tree->getTree($matches[1],$url);
	return $arr_data;
}
/**
 * Store category of baomoi
 *
 * @param unknown_type $data
 * @param unknown_type $section_id
 * @return unknown
 */
function mosModelCategorySaveBAOMOI($data , $section_id = 1)
{	
	if (!is_array($data) || count($data)<1) {
		return false;
	}
	
	global $database;
	$db	=	$database;
	foreach ($data as $category)
	{
		// check article2010_category_baomoi
		$query	=	'SELECT COUNT(*) 
					FROM `#__article2010_category_baomoi` 
					WHERE `link` = '.$db->Quote($category->link);
		$db->setQuery($query);		
		$result	=	$db->loadResult();
		if ($result) {
			continue;
		}
		$jl_category	=	'';
		$parent			=	'';
		if ($category->parent != -1) {
			$query	=	'SELECT id,jl_category  
											FROM `#__article2010_category_baomoi` 
											WHERE `link`='. $db->Quote($data[$category->parent]->link);
			$db->setQuery($query);
			$db->loadObject($parent);			
			$jl_category	=	$parent->jl_category;
			$parent			=	$parent->id;
		}
		// store category
		$row_caregory				=	new	mosCategory($db);
		$row_caregory->parent_id	=	$parent;
		$row_caregory->title		=	$category->title;
		$row_caregory->name			=	$category->title;
		$row_caregory->section		=	$section_id;
				
		if (! $row_caregory->store ()) {
			echo "<script> alert('" . $row_caregory->getError () . "'); window.history.go(-1); </script>\n";
			exit ();
		}
		// store baomoi_category
		$row_vov_caregory				=	new mosBaomoiCategory($db);
		$row_vov_caregory->jl_category	=	$row_caregory->id;
		$row_vov_caregory->title		=	$category->title;
		$row_vov_caregory->link			=	$category->link;
		$row_vov_caregory->parent		=	$parent;
		if (! $row_vov_caregory->store ()) {
			echo "<script> alert('" . $row_vov_caregory->getError () . "'); window.history.go(-1); </script>\n";
			exit ();
		}
	}
	return true;
}

//////////////////////////////////////////////////////////////////////////////////////
	//////////////	FOR VIETNAMNET	/////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////

// cat_alias và cat_title
function mosModelCategoryGetVNNET ($url = null)
{
	if ($url == null) {
		$url		=	'http://english.vietnamnet.vn/';
	}
	
	$html		= 	loadHtml($url);
	$obj		= 	$html->find('div[class="home-menu"]',0);
	$response	= 	$obj->innertext;
	
	$reg		=	'/<a href="([^"]+)"\s*(class="sub-link"|)>(.*?)<\/a>/ism';

	if (!preg_match_all($reg,$response,$matches)) 
	{
		$message	=	'#341 models Newsktdt mosModelNewsktdtGetNews. Invalid get news content';
		array_push($arrErr,$message);
		return false;
	}
	$list_cat_alias = $matches[1];
	$list_cat_title = $matches[3];
	
	$arr_cat_alias = array();
	for ($i=0;$i<count($list_cat_alias);$i++)
	{
		$source_cat = 'http://english.vietnamnet.vn'.$list_cat_alias[$i];
		$obj_cat = new stdClass();
		$link_cat_item = explode('/',$list_cat_alias[$i]);
		$cat_alias = $link_cat_item[2];
		
		if ($cat_alias == 'index.html') continue;
	
		$obj_cat->source_cat = $source_cat;
		if ($cat_alias != null) {
			$obj_cat->cat_alias = $cat_alias;
			$obj_cat->title = $list_cat_title[$i];
		}
		$arr_cat_alias[] = $obj_cat;
	}
	return $arr_cat_alias;
}

// Lưu category vào csdl
function mosModelCategorySaveVNNET($data)
{
	global $database;
	$db	=	& $database;
	for ($i=0; $i<count($data); $i++)
	{
		$query = "INSERT INTO #__article2010_category_vietnamnet
						SET 
						title=".$db->Quote(trim($data[$i]->title)).",
						alias_origional=".$db->Quote(trim($data[$i]->cat_alias)).",
						isparent= 0,
						publish = 1,
						domain=".$db->Quote(trim($data[$i]->source_cat))."
						
					ON DUPLICATE KEY UPDATE 
						alias_origional=".$db->Quote(trim($data[$i]->cat_alias));
						
		
		$db->setQuery ( $query );
		
		if (!$db->query()) {
			$this->arr_err[]	=	"Error insert or update data ".$query;
			return false;
		}
	}	
	
	return true;
}


//////////////////////////////////////////////////////////////////////////////////////
//////////////////	FOR THANHNIEN	//////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////

// cat_alias và cat_title
function mosModelCategoryGetVNTHANHNIEN ($url = null)
{
	if ($url == null) {
		$url		=	'http://www.thanhniennews.com/Pages/Politics.aspx';
	}
	
	$html		= 	loadHtml($url);
	$obj		= 	$html->find('select[id="ctl00_ctl12_g_c0a1ce59_a786_4bb3_b198_00f244316600_ctl00"]',0);
	$response	= 	$obj->innertext;
	
	$reg		=	'/<option[^>]*value="([^"]+)">(.*?)<\/option>/ism';

	if (!preg_match_all($reg,$response,$matches)) 
	{
		$message	=	'#341 models Newsktdt mosModelNewsktdtGetNews. Invalid get news content';
		array_push($arrErr,$message);
		return false;
	}
	$value = $matches[1];
	$list_cat_title = $matches[2];
	
	$arr_obj_cat = array();
	for ($i=0;$i<count($list_cat_title);$i++)
	{
		
		if ($value[$i] == '0') {
			continue;
		}
		if ($value[$i] != '0') {
			$arr_obj_cat[] = $list_cat_title[$i];
		}
		
	}
	return $arr_obj_cat;
}

// Lưu category vào csdl
function mosModelCategorySaveVNTHANHNIEN($data)
{
	global $database,$arrErr;
	$db	=	& $database;
	
	for ($i=0; $i<count($data); $i++)
	{
		$query = "INSERT INTO #__article2010_category_thanhnien
						SET 
						title=".$db->Quote($data[$i]).",
						isparent= 0,
						publish = 1
				  ON DUPLICATE KEY UPDATE 
						isparent= 0";
		$db->setQuery ( $query );
		
		if (!$db->query()) {
			$message	=	'#341 models Newsktdt mosModelNewsktdtGetNews. Invalid get news content';
			array_push($arrErr,$message);
			return false;
		}		
	}
	return true;
}


////////////////////////////////////////////////////////////////////////////
/////////		FOR KTDT			//////////
////////////////////////////////////////////////////////////////////////////

function mosModelCategoryGetKTDT($url)
{
	$url		=	'http://www.ktdt.com.vn/';
	$browser	=	new phpWebHacks();
	$response	=	$browser->get($url);
	$reg		=	'/<TABLE id=table498[^>]*>(.*?)<\/TABLE>\s*<TABLE id=table498[^>]+>/ism';
	if (!preg_match($reg,$response,$matches)) 
	{
		$message	=	'#341 models Newsktdt mosModelNewsktdtGetNews. Invalid get news content';
		array_push($arrErr,$message);
		return false;
	}
	$list_news = $matches[1];
	$html	=	loadHtmlString($list_news);
	$href	=	new href();
	preg_match_all('/<a class="(menu|menu-sub|menu_sub|menu_sub2)" href="([^"]+)">(.*?)<\/a>/ism',$html,$parent_cat);
	$arr_cat = array();
	for ($i=0;$i<count($parent_cat[2]);$i++)
	{
		$obj_cat = new stdClass();
		$cat_link = explode('CatID=',$parent_cat[2][$i]);
		
		$obj_cat->id_origional 	= $cat_link[1]; 
		$obj_cat->title 		= $parent_cat[3][$i]; 
		$obj_cat->str_url 		= $parent_cat[2][$i]; 
		$obj_cat->domain 		= $url; 
		$obj_cat->isparent = 0;
		
		$arr_cat[] = $obj_cat;
	}
	return $arr_cat;
}

function mosModelCategorySaveKTDT($arr_data)
{
	global $arrErr, $database;
	$db	=	& $database;	
	for ($i=0; $i<count($arr_data); $i++)
	{
		$data	=	$arr_data[$i];
		$query = "INSERT INTO #__article2010_category
						SET id_origional =".trim($data->id_origional).",
						title=".$db->Quote(trim($data->title)).",
						domain=".$db->Quote(trim('http://www.ktdt.com.vn/showCat.asp?CatID=').trim($data->id_origional)).",
						isparent=".$db->Quote(trim($data->isparent))."
						
					ON DUPLICATE KEY UPDATE 					
						title=".$db->Quote(trim($data->title)).",
						domain=".$db->Quote(trim('http://www.ktdt.com.vn/showCat.asp?CatID=').trim($data->id_origional));
		
		$db->setQuery ( $query );		
		if (!$db->query()) {
			array_push($arrErr,"Error insert or update data ".$query);
			return false;
		}
	}	
	return true;
}

////////////////////////////////////////////////////////////////////////////
/////////		FOR NGUOI LAO DONG			//////////
////////////////////////////////////////////////////////////////////////////
function mosModelCategoryGetNGUOILAODONG($url = null)
{
	if ($url == null) {
		$url		=	'http://nld.com.vn/';
	}
	
	$html		= 	loadHtml($url);
	$obj		= 	$html->find('div[id="nav"]',0);
	$response	= 	$obj->innertext;
	$reg		=	'/<a href="([^"]+)"[^>]*>(.*?)<\/a>/ism';

	if (!preg_match_all($reg,$response,$matches)) 
	{
		$message	=	'#341 models Newsktdt mosModelNewsktdtGetNews. Invalid get news content';
		array_push($arrErr,$message);
		return false;
	}
	$value = $matches[1];
	$list_cat_title = $matches[2];
	
	$arr_obj_cat = array();
	for ($i=0;$i<count($value);$i++)
	{
		
		$obj_category = new stdClass();
		if ($value[$i] == '/') {
			continue;
		}
		$arr_value = explode('/',$value[$i]);
		
		$alias = explode('.',$arr_value[2]);
		$alias_origional = $alias[0];
		if(strlen($arr_value[1])<=5)
		{
			continue;
		}
		if(strlen($arr_value[1])<=7)
		{
			$obj_category->title = strip_tags($list_cat_title[$i]);
			$obj_category->alias_origional = strip_tags($alias_origional);
			$obj_category->id = substr($arr_value[1],3,4);
			$obj_category->parent = 0;
			$arr_obj_cat[] = $obj_category;
			continue;
		}
		
		$obj_category->title = strip_tags($list_cat_title[$i]);
		$obj_category->alias_origional = strip_tags($alias_origional);
		$obj_category->id = substr($arr_value[1],6,4);
		$obj_category->parent = substr($arr_value[1],1,4);
		$arr_obj_cat[] = $obj_category;
		
	}
	
	return $arr_obj_cat;
}

// Lưu category vào csdl
function mosModelCategorySaveNGUOILAODONG($data)
{
	global $database,$arrErr;
	$db	=	& $database;
	
	for ($i=0; $i<count($data); $i++)
	{
		$link	=	"http://nld.com.vn/p".$data[$i]->parent."c".$data[$i]->id."/".$data[$i]->alias_origional.".htm";
		$query = "INSERT INTO #__article2010_category_nguoilaodong
						SET 
						title=".$db->Quote($data[$i]->title).",
						parent=".$db->Quote($data[$i]->parent).",
						alias_origional=".$db->Quote($data[$i]->alias_origional).",
						id_origional=".$db->Quote($data[$i]->id).",
						domain = ".$db->Quote($link).",
						publish = 1
				  ON DUPLICATE KEY UPDATE 
				  		title=".$db->Quote($data[$i]->title).",
				  		alias_origional=".$db->Quote($data[$i]->alias_origional).",
				  		domain = ".$db->Quote($link).",
						parent=".$db->Quote($data[$i]->parent);
		$db->setQuery ( $query );
		
		if (!$db->query()) {
			$message	=	'#341 models Newsktdt mosModelNewsktdtGetNews. Invalid get news content';
			array_push($arrErr,$message);
			return false;
		}		
	}
	return true;
}

////////////////////////////////////////////////////////////////////////////
/////////		FOR THE THAO VAN HOA			//////////
////////////////////////////////////////////////////////////////////////////
function mosModelCategoryGetTTVH($url = null)
{
	if ($url == null) {
		$url		=	'http://thethaovanhoa.vn/';
	}
	
	$html		= 	loadHtml($url);
	$response = $html->innertext;
	$arr_menu = array();
	
	$obj_parent_menu		= 	$html->find('div[id="nav"]',0);
	$response_parent_menu 	= 	$obj_parent_menu->innertext;
	
	$reg_parent_menu = '/<li><a href="([^"]+)"[^>]+id="menu(\d+)">(.*?)<\/a><\/li>/ism';
	preg_match_all($reg_parent_menu,$response_parent_menu,$matches);	
	$arr_cat_link	= $matches[1];
	$arr_cat_id 	= $matches[2];
	$arr_cat_title 	= $matches[3];
	for ($i=0;$i<count($arr_cat_id);$i++)
	{
		$obj_parent_menu = new stdClass();
		$obj_parent_menu->id = $arr_cat_id[$i];
		$obj_parent_menu->title = $arr_cat_title[$i];
		$obj_parent_menu->link = $arr_cat_link[$i];
		$obj_parent_menu->parent='';
		$arr_menu[]=$obj_parent_menu;
	}
	
// Sub_menu <ul class="clearfix" id="submenu128" style="display: none">
	
	$preg_group_sub_menu = '/<ul[^>]*id="submenu(\d+)"[^>]*>(.*?)<\/ul>/ism';
	preg_match_all($preg_group_sub_menu,$response,$matches_group);
	$group_sub_menu =  $matches_group[2];
	$parent_group_sub_menu =  $matches_group[1];

	for ($j=0;$j<count($group_sub_menu);$j++)
	{
		
		$reg_sub_menu_item = '/<li><a href="([^"]+)">(.*?)<\/a><\/li>/ism';
		preg_match_all($reg_sub_menu_item,$group_sub_menu[$j],$matches);
		$link_menu = $matches[1];
		$title_menu = $matches[2];
		for ($n=0;$n<count($link_menu);$n++)
		{
			$obj_sub_menu = new stdClass();
			$explode_link_menu = explode('/',$link_menu[$n]);
			$id_sub_menu = $explode_link_menu[count($explode_link_menu)-2];
			$explode_id_sub_menu = explode('CT',$id_sub_menu);
			$obj_sub_menu->id = $explode_id_sub_menu[0];
			$obj_sub_menu->title = $title_menu[$n];		
			$obj_sub_menu->link = $link_menu[$n];		
			$obj_sub_menu->parent = $parent_group_sub_menu[$j];
			$arr_menu[]=$obj_sub_menu;
		}
		
		
		
	}
//	for ($a=0;$a<count($arr_menu);$a++)
//	{
//		var_dump($arr_menu[$a]);echo '<br/>';
//	}
//	die();
	
	return $arr_menu;
}


// Lưu category vào csdl
function mosModelCategorySaveTTVH($data)
{
	global $database,$arrErr;
	$db	=	& $database;
//	var_dump($data); die();
	for ($i=0; $i<count($data); $i++)
	{
		$link	=	'http://thethaovanhoa.vn'.$data[$i]->link;
		$query = "INSERT INTO #__article2010_category_thethaovanhoa
						SET 
						title = ".$db->Quote($data[$i]->title).",
						parent = ".$db->Quote($data[$i]->parent).",
						id_origional = ".$db->Quote($data[$i]->id).",
						domain = ".$db->Quote($link).",
						publish = 1
				  ON DUPLICATE KEY UPDATE 
				  		title=".$db->Quote($data[$i]->title).",
				  		domain = ".$db->Quote($link).",
						parent=".$db->Quote($data[$i]->parent);
		$db->setQuery ( $query );
	
		if (!$db->query()) {
			$message	=	'#341 models Newsktdt mosModelNewsktdtGetNews. Invalid get news content';
			array_push($arrErr,$message);
			return false;
		}		
	}
	return true;
}

////////////////////////////////////////////////////////////////////////////
/////////		FOR AUTONET			//////////
////////////////////////////////////////////////////////////////////////////
function mosModelCategoryGetATN($url = null)
{
	if ($url == null) {
		$url		=	'http://autonet.com.vn//common/v1/js/layout_3441.js';
	}
	
	$html		= 	loadHtml($url);
	$response = $html->innertext;
	$arr_menu = array();
	$reg_menu = '/function VO14893\(\)\{\s*document.write\("(.*?)"\);\s*\}/ism';
	
	preg_match($reg_menu,$response,$matches);
	$group_menu = str_replace('\\','',$matches[1]);
	$obj_group_menu = loadHtmlString($group_menu);
	
	$parent_menu = $obj_group_menu->find('div[id="parentcate"]',0);
	$parent_menu = $parent_menu->innertext;
// parent menu	
	$reg_parent_menu_item = '/<div id="(\d+)" url="\/([^"]+)\/">(.*?)<\/div>/ism';
	preg_match_all($reg_parent_menu_item,$parent_menu,$match_menu_parent);
	
	for ($i=0;$i<count($match_menu_parent[1]);$i++)
	{
		$obj_menu_parent = new stdClass();
		$obj_menu_parent->id_original = $match_menu_parent[1][$i];
		$obj_menu_parent->menu_alias = $match_menu_parent[2][$i];
		$obj_menu_parent->title = $match_menu_parent[3][$i];
		$obj_menu_parent->parent = 0;
		$arr_menu[] = $obj_menu_parent;
	}
// sub menu	
	$parent_menu = $obj_group_menu->find('div[id="subcate"]',0);
	$parent_menu = $parent_menu->innertext;
	
	$reg_parent_menu_item = '/<div id="(\d+)" class="(\d+)" url="\/([^"]+)\/">(.*?)<\/div>/ism';
	preg_match_all($reg_parent_menu_item,$parent_menu,$match_menu_sub);
	
	for ($j=0;$j<count($match_menu_sub[1]);$j++)
	{
		$obj_menu_sub = new stdClass();
		$obj_menu_sub->id_original = $match_menu_sub[1][$j];
		$obj_menu_sub->menu_alias = $match_menu_sub[3][$j];
		$obj_menu_sub->title = $match_menu_sub[4][$j];
		$obj_menu_sub->parent = $match_menu_sub[2][$j];
		$arr_menu[] = $obj_menu_sub;
	}
	
	return $arr_menu;
}


// Lưu category vào csdl
function mosModelCategorySaveATN($data)
{
	global $database,$arrErr;
	$db	=	& $database;
	
	for ($i=0; $i<count($data); $i++)
	{
		$link	=	"http://autonet.com.vn/".$data[$i]->menu_alias;
		
		if ($data[$i]->parent == 0) {
			$public = 0;
		}
		else $public = 1;
		$query = "INSERT INTO #__article2010_category_autonet
						SET 
						title=".$db->Quote($data[$i]->title).",
						parent=".$db->Quote($data[$i]->parent).",
						id_origional=".trim($data[$i]->id_original).",
						alias_origional=".$db->Quote($data[$i]->menu_alias).",
						domain = ".$db->Quote($link).",
						publish = ".$public ."
					ON DUPLICATE KEY UPDATE 
				  		title=".$db->Quote($data[$i]->title).",
				  		alias_origional=".$db->Quote($data[$i]->menu_alias).",
				  		domain = ".$db->Quote($link).",
						parent=".$db->Quote($data[$i]->parent);
				  
		$db->setQuery ( $query );
		
		if (!$db->query()) {
			$message	=	'#341 models Newsktdt mosModelNewsktdtGetNews. Invalid get news content';
			array_push($arrErr,$message);
			return false;
		}		
	}
	return true;
}

////////////////////////////////////////////////////////////////////////////
/////////		FOR AUTOPRO			//////////
////////////////////////////////////////////////////////////////////////////
function mosModelCategoryGetATP($url = null)
{
	if ($url == null) {
		$url		=	'http://autopro.com.vn/home.chn';
	}
	
	$html		= 	loadHtml($url);
	$nav_menu = $html->find('ul[id="Header1_mainMenu"]',0);
	$nav_menu_list = $nav_menu->innertext;
	
	$arr_menu = array();
	
	$reg_menu = '/<a href="\/([^"]+).chn"[^>]*title="([^"]*)"[^>]*>(.*?)<\/a>/ism';
	
	preg_match_all($reg_menu,$nav_menu_list,$matches_parent);
	
	for ($i=0;$i<count($matches_parent[3]);$i++)
	{
		if ($matches_parent[1][$i] == 'home') {
			continue;
		}
		$obj_menu_parent = new stdClass();
		
		$obj_menu_parent->alias_original	=	$matches_parent[1][$i];
		$obj_menu_parent->title 			= 	trim(strip_tags($matches_parent[3][$i]));
		if ($obj_menu_parent->title == '') {
			$obj_menu_parent->title 		= 	trim(strip_tags($matches_parent[2][$i]));
		}
		$obj_menu_parent->parent = '';
		$obj_menu_parent->public = 1;
		
	// sub menu
		$url_sub = 'http://autopro.com.vn/'.$obj_menu_parent->alias_original.'.chn';
		$html_sub		= 	loadHtml($url_sub);
		
		$sub_menu = $html_sub->find('div[id="ctl00_Header1_subMenu"]',0);
		$str_sub_menu = $sub_menu->innertext;

		$str_sub_menu = str_replace("\r\n",'',$str_sub_menu);

		$reg_sub_menu = '/<a href="\/([^"]+).chn"[^>]*>(.*?)<\/a>/ism';
		
		preg_match_all($reg_sub_menu,$str_sub_menu,$matches_sub);
		if ($matches_sub[1]) {
			$obj_menu_parent->public = 0;
			$arr_menu[] = $obj_menu_parent;
			for ($j=0;$j<count($matches_sub[2]);$j++)
			{				
				$obj_menu_sub = new stdClass();
				
				$obj_menu_sub->alias_original	=	$matches_sub[1][$j];
				$obj_menu_sub->title			=	trim(strip_tags($matches_sub[2][$j]));
				$obj_menu_sub->parent			=	$matches_parent[1][$i];
				$obj_menu_sub->public = 1;
				$arr_menu[] 					=	$obj_menu_sub;
			}
		}else {
			$arr_menu[] = $obj_menu_parent;
		}		
	}	
	return $arr_menu;
}


// Lưu category vào csdl
function mosModelCategorySaveATP($data)
{
	global $database,$arrErr;
	
	$db	=	& $database;
	
	for ($i=0; $i<count($data); $i++)
	{		
		$link	=	'http://autopro.com.vn/'.$data[$i]->alias_original;
		if ($data[$i]->parent != '') {
			$query = "INSERT INTO #__article2010_category_autopro 
							SET title = ".$db->Quote($data[$i]->title).",
							parent = (SELECT B.id FROM #__article2010_category_autopro as B WHERE B.alias_origional = ".$db->Quote($data[$i]->parent)."),
							alias_origional = ".$db->Quote($data[$i]->alias_original).",
							domain = ".$db->Quote($link).",
							publish = ".$data[$i]->public."
					  ON DUPLICATE KEY UPDATE 
					  		title = ".$db->Quote($data[$i]->title).",							
							domain = ".$db->Quote($link).",
							publish = ".$data[$i]->public.",
							parent = (SELECT C.id FROM #__article2010_category_autopro as C WHERE C.alias_origional = ".$db->Quote($data[$i]->parent).")";
		}
		else {
			$query = "INSERT INTO #__article2010_category_autopro 
						SET 
						title = ".$db->Quote($data[$i]->title).",
						parent = '',
						alias_origional=".$db->Quote($data[$i]->alias_original).",
						domain = ".$db->Quote($link).",
						publish = ".$data[$i]->public."
				  ON DUPLICATE KEY UPDATE 
				  		title = ".$db->Quote($data[$i]->title).",
				  		domain = ".$db->Quote($link).",						
						publish = ".$data[$i]->public.",
						parent = ''";
		}
		$db->setQuery ( $query );
		
		if (!$db->query()) {
			$message	=	'#341 models Newsktdt mosModelNewsktdtGetNews. Invalid get news content';
			array_push($arrErr,$message);
			return false;
		}		
	}
	return true;
}